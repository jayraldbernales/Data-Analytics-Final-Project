import pandas as pd
import numpy as np

df = pd.read_csv('Sales_Profit_Data_Electrical_Appliances.csv')

df['Order Date'] = pd.to_datetime(df['Order Date'], format='%m/%d/%y')
df['Order Qty'] = df['Order Qty'].astype(int)
df['Profit'] = pd.to_numeric(df['Profit'], errors='coerce')

Q1 = df['Profit'].quantile(0.25)
Q3 = df['Profit'].quantile(0.75)
IQR = Q3 - Q1
lower_bound = Q1 - 1.5 * IQR
upper_bound = Q3 + 1.5 * IQR
df['Profit'] = np.clip(df['Profit'], lower_bound, upper_bound)

df.to_csv('cleaned_appliances.csv', index=False)
df.to_json('data.json', orient='records', date_format='iso')
print('Cleaning done: 0 missings/duplicates; dates/types fixed; outliers capped.')